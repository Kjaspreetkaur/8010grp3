﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Charges
{
    class ChargesMVVM : INotifyPropertyChanged
    {
		private const decimal STAY_CHARGE_PER_DAY = 350;

		private decimal _days;

		public decimal Days
		{
			get { return _days; }
			set { _days = value; NotifyPropertyChanged(); }
		}

		private decimal _medicationCharges;

		public decimal MedicationCharges
		{
			get { return _medicationCharges; }
			set { _medicationCharges = value; NotifyPropertyChanged(); }
		}

		private decimal _surgicalCharges;

		public decimal SurgicalCharges
		{
			get { return _surgicalCharges; }
			set { _surgicalCharges = value; NotifyPropertyChanged(); }
		}

		private decimal _labFees;

		public decimal LabFees
		{
			get { return _labFees; }
			set { _labFees = value; NotifyPropertyChanged(); }
		}

		private decimal _rehabilitationCharges;

		public decimal RehabilitationCharges
		{
			get { return _rehabilitationCharges; }
			set { _rehabilitationCharges = value; NotifyPropertyChanged(); }
		}

		private decimal _totalCharges;

		public decimal TotalCharges
		{
			get { return _totalCharges; }
			set { _totalCharges = value; NotifyPropertyChanged(); }
		}

		private decimal CalcStayCharges()
		{
			decimal _totalStayCharge = STAY_CHARGE_PER_DAY * Days;
			return _totalStayCharge;
		}

		private decimal CalcMiscCharges()
		{
			decimal _miscCharges = MedicationCharges + SurgicalCharges + LabFees + RehabilitationCharges;
			return _miscCharges;
		}

		public decimal CalcTotalCHarges()
		{
			TotalCharges = CalcStayCharges() + CalcMiscCharges();
			return TotalCharges;
		}

		public void ResetValues()
		{
			Days = MedicationCharges = SurgicalCharges = LabFees = RehabilitationCharges = 0;
		}

		public event PropertyChangedEventHandler PropertyChanged;
		private void NotifyPropertyChanged([CallerMemberName] String PropertyName = " ")
		{
			if (PropertyName == null)
			{
				throw new ArgumentNullException(nameof(PropertyName));
			}

		}
	}
}
