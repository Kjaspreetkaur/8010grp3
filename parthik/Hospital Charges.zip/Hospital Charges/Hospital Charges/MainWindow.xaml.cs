﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_Charges
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		ChargesMVVM Charges = new ChargesMVVM();
		public MainWindow()
		{
			InitializeComponent();
			DataContext = Charges;
		}

		private void Calculate_Click(object sender, RoutedEventArgs e)
		{
			decimal _parseValue;
			if(decimal.TryParse(tbxDays.Text,out _parseValue) && decimal.TryParse(tbxMedicationCharges.Text, out _parseValue) &&
			   decimal.TryParse(tbxSurgicalCHarges.Text, out _parseValue) && decimal.TryParse(tbxLabfees.Text, out _parseValue) &&
			   decimal.TryParse(tbxRehabilitationCharges .Text, out _parseValue))
			{
				decimal _totalcharges;
				_totalcharges = Charges.CalcTotalCHarges() ;
				Result.Content = "Total Hospital Charge is $ "+ _totalcharges ;
				Result.FontSize = 20;
			}
			else
			{
				Result.Content = "Please enter numeric values";
				Result.FontSize = 20;
			}
		}

		private void Reset_Click(object sender, RoutedEventArgs e)
		{
			Result.Content = "Result will be displayed here";
			Result.FontSize = 15;
			tbxDays.Text = "0";
			tbxLabfees.Text = "0";
			tbxMedicationCharges.Text = "0";
			tbxSurgicalCHarges.Text = "0";
			tbxRehabilitationCharges.Text = "0";
			Charges.ResetValues();
		}
	}
}
