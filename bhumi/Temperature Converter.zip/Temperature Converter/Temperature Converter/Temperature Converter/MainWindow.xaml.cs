﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Temperature_Converter
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
     
	    private void ConvertToFahrenheit_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				double Cel = double.Parse(tbxInput.Text);
				double Far = (9.0 / 5.0) * Cel + 32;
				ConvertedValue.Content = Cel + " Celcius = " + Far + " Fahrenheit";
				ConvertedValue.FontSize = 25;

			}
			catch
			{
				MessageBox.Show("Something went wrong please try again!!");
			}

		}
		private void ConvertToCelcius_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				double Far = double.Parse(tbxInput.Text);
				double Cel = (5.0 / 9.0) * (Far - 32);
				ConvertedValue.Content = Far + " Fahrenheit = " + Cel + " Celcius";
				ConvertedValue.FontSize = 25;

			}
			catch
			{
				MessageBox.Show("Something went wrong please try again!!");
			}
		}


	}
}
