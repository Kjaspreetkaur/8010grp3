﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void button_click(object sender, RoutedEventArgs e)
        {
            if (sender.Equals(Ace_Diamonds))
                label1.Content = "Ace_Diamonds";

            if (sender.Equals(Ace_Clubs))
                label1.Content = "Ace_Clubs";

            if (sender.Equals(Ace_Hearts))
                label1.Content = "Ace_Hearts";

            if (sender.Equals(King_Clubs))
                label1.Content = "King_Clubs";

            if (sender.Equals(Ace_Spades))
                label1.Content = "Ace_Spades";


        }
    }
}

