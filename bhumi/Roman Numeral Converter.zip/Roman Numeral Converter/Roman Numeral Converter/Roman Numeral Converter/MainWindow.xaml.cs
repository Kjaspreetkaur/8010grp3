﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Roman_Numeral_Converter
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void ConvertToRoman_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int intVal;
				intVal = int.Parse(IntegerValue.Text);
				if (intVal > 10 || intVal < 1)
				{
					MessageBox.Show("Please enter any number between 1 to 10");
				}
				else
				{
					switch (intVal)
					{
						case 1:
							Display.Content = "1 --> I";
							break;
						case 2:
							Display.Content = "2 --> II";
							break;
						case 3:
							Display.Content = "3 --> III";
							break;
						case 4:
							Display.Content = "4 --> IV";
							break;
						case 5:
							Display.Content = "5 --> V";
							break;
						case 6:
							Display.Content = "6 --> VI";
							break;
						case 7:
							Display.Content = "7 --> VII";
							break;
						case 8:
							Display.Content = "8 --> VIII";
							break;
						case 9:
							Display.Content = "9 --> IX";
							break;
						case 10:
							Display.Content = "10 --> X";
							break;
					}

				}
			}
			catch
			{
				MessageBox.Show("Please enter the numbers between 1 to 10 only");
			}

		}

		private void Reset_Click(object sender, RoutedEventArgs e)
		{
			Display.Content = "Enter Numeric value:";
			IntegerValue.Text = "";

		}
	}
}
